#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai
__license__ = 'GPL v3'

import logging
import datetime

from qt.core import (  # type: ignore
    Qt, QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QProgressBar, QScrollArea, QWidget, QGridLayout, QCheckBox,
    QThread, pyqtSignal, QObject, QGroupBox, QSplitter, QTextBrowser,
    QSizePolicy, QFrame, QTabWidget
)

try:
    from urllib.request import urlopen, Request
except ImportError:
    from urllib2 import urlopen, Request # type: ignore

from calibre.gui2 import error_dialog, info_dialog, question_dialog  # type: ignore


UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'


# ── GUI log handler ────────────────────────────────────────────────────────────

class _QtLogSignaller(QObject):
    """Plain QObject whose sole purpose is to carry a thread-safe pyqtSignal."""
    log_line = pyqtSignal(str)          # HTML-coloured line


class GUILogHandler(logging.Handler):
    """
    Logging handler that forwards every record to the dialog's Log tab
    via a Qt signal (thread-safe).  One instance is shared per dialog.
    """

    # Colour map: level → (background or text colour, bold?)
    _COLOURS = {
        logging.DEBUG:    ('#888888', False),
        logging.INFO:     ('#cccccc', False),
        logging.WARNING:  ('#ffaa00', True),
        logging.ERROR:    ('#ff4444', True),
        logging.CRITICAL: ('#ff0000', True),
    }

    def __init__(self, signaller):
        super().__init__()
        self._signaller = signaller
        self.setFormatter(logging.Formatter('%(asctime)s  %(levelname)-8s  %(message)s',
                                            datefmt='%H:%M:%S'))

    def emit(self, record):
        try:
            msg = self.format(record)
            colour, bold = self._COLOURS.get(record.levelno, ('#cccccc', False))
            safe = (msg
                    .replace('&', '&amp;')
                    .replace('<', '&lt;')
                    .replace('>', '&gt;'))
            if bold:
                html = '<span style="color:{};font-weight:bold">{}</span>'.format(colour, safe)
            else:
                html = '<span style="color:{}">{}</span>'.format(colour, safe)
            self._signaller.log_line.emit(html)
        except Exception:
            pass


# ── Worker thread ──────────────────────────────────────────────────────────────

class FetchWorker(QThread):
    progress  = pyqtSignal(int, str)
    book_done = pyqtSignal(int, object, object)   # book_id, mi, result_dict
    finished  = pyqtSignal()
    error_sig = pyqtSignal(str)

    def __init__(self, db, ids, parent=None):
        QThread.__init__(self, parent)
        self.db     = db
        self.ids    = ids
        self._abort = False
        # Signaller used by GUILogHandler — lives on the worker thread but
        # its signal is connected from the main thread after construction.
        self._log_signaller = _QtLogSignaller()

    def abort(self):
        self._abort = True

    def run(self):
        from calibre_plugins.metadata_plus.fetch_engine import fetch_for_book  # type: ignore

        # Install our GUI handler onto the plugin logger for the duration
        # of this worker's run so every log.* call inside fetch_engine
        # (and providers, fuzzy, etc.) is forwarded to the Log tab.
        plugin_log = logging.getLogger('metadata_plus')
        gui_handler = GUILogHandler(self._log_signaller)
        gui_handler.setLevel(logging.DEBUG)
        plugin_log.addHandler(gui_handler)

        total = len(self.ids)
        ts_start = datetime.datetime.now().strftime('%H:%M:%S')
        self._log_signaller.log_line.emit(
            '<span style="color:#44aaff;font-weight:bold">'
            '════ Metadata++ run started at {} — {} book(s) ════'
            '</span>'.format(ts_start, total)
        )

        for i, book_id in enumerate(self.ids):
            if self._abort:
                self._log_signaller.log_line.emit(
                    '<span style="color:#ffaa00;font-weight:bold">'
                    '⚠  Fetch aborted by user after {}/{} books.'
                    '</span>'.format(i, total)
                )
                break

            mi    = self.db.get_metadata(book_id, index_is_id=True)
            title = mi.title or 'Unknown'

            self.progress.emit(
                int(i / total * 100),
                'Fetching ({}/{}): {}'.format(i + 1, total, title[:55])
            )

            # ── Book header in log ─────────────────────────────────────────
            self._log_signaller.log_line.emit(
                '<span style="color:#aaddff;font-weight:bold">'
                '── Book {}/{}: &quot;{}&quot; (id={}) ──'
                '</span>'.format(i + 1, total,
                                 title[:60].replace('&','&amp;').replace('<','&lt;'),
                                 book_id)
            )

            data  = None
            error = None
            try:
                data = fetch_for_book(self.db, book_id)
            except Exception as e:
                error = 'Error on "{}": {}'.format(title[:40], e)
                self.error_sig.emit(error)

            # ── Book result summary in log ─────────────────────────────────
            if error:
                self._log_signaller.log_line.emit(
                    '<span style="color:#ff4444;font-weight:bold">'
                    '✘  EXCEPTION: {}'
                    '</span>'.format(error.replace('<','&lt;'))
                )
            elif data:
                sources = ', '.join(data.get('sources', []) or ['?'])
                fields  = [k for k in ('title','authors','publisher','pubdate',
                                       'comments','tags','rating','language',
                                       'identifiers','cover_url')
                           if data.get(k)]
                self._log_signaller.log_line.emit(
                    '<span style="color:#66dd66;font-weight:bold">'
                    '✔  Result OK — sources: {}  |  fields: {}'
                    '</span>'.format(
                        sources.replace('<','&lt;'),
                        ', '.join(fields) or 'none'
                    )
                )
            else:
                self._log_signaller.log_line.emit(
                    '<span style="color:#ff8800;font-weight:bold">'
                    '✘  No metadata found for this book (all sources returned nothing).'
                    '</span>'
                )

            self.book_done.emit(book_id, mi, data)

        self.progress.emit(100, 'Done — {} book(s) processed'.format(total))

        ts_end = datetime.datetime.now().strftime('%H:%M:%S')
        self._log_signaller.log_line.emit(
            '<span style="color:#44aaff;font-weight:bold">'
            '════ Run finished at {} ════'
            '</span>'.format(ts_end)
        )

        # Remove our handler so it doesn't accumulate on reruns
        plugin_log.removeHandler(gui_handler)
        self.finished.emit()


# ── Per-book result panel ──────────────────────────────────────────────────────

class BookResultPanel(QGroupBox):
    FIELDS = [
        ('title',       'Title'),
        ('authors',     'Authors'),
        ('publisher',   'Publisher'),
        ('pubdate',     'Pub. Date'),
        ('comments',    'Description'),
        ('tags',        'Tags / Categories'),
        ('rating',      'Rating'),
        ('language',    'Language'),
        ('identifiers', 'Identifiers'),
    ]

    def __init__(self, book_id, mi, data, parent=None):
        label = mi.title or 'Book #{}'.format(book_id)
        QGroupBox.__init__(self, label[:80], parent)
        self.book_id    = book_id
        self.mi         = mi
        self.data       = data
        self.checkboxes = {}
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        if not self.data:
            layout.addWidget(QLabel(
                '<i>No metadata found from any source.</i><br>'
                '<small>Check the <b>Log</b> tab above for per-source errors '
                '(e.g. a source timing out or being blocked) — that usually '
                'explains why nothing came back for this book.</small>'))
            return

        sources = ', '.join(self.data.get('sources', []))
        src_lbl = QLabel('<small><b>Sources:</b> {}</small>'.format(sources))
        layout.addWidget(src_lbl)

        grid = QGridLayout()
        grid.setColumnStretch(2, 1)

        row = 0
        for key, label in self.FIELDS:
            val = self.data.get(key)
            if not val:
                continue
            if isinstance(val, list):
                display = ', '.join(str(v) for v in val)
            elif isinstance(val, dict):
                display = ', '.join('{}:{}'.format(k, v) for k, v in val.items())
            else:
                display = str(val)

            cb = QCheckBox()
            cb.setChecked(True)
            lbl_key = QLabel('<b>{}</b>'.format(label))
            lbl_key.setFixedWidth(100)
            lbl_val = QLabel(display[:300] + ('…' if len(display) > 300 else ''))
            lbl_val.setWordWrap(True)

            grid.addWidget(cb,      row, 0)
            grid.addWidget(lbl_key, row, 1)
            grid.addWidget(lbl_val, row, 2)
            self.checkboxes[key] = cb
            row += 1

        layout.addLayout(grid)

    def get_selected(self):
        if not self.data:
            return None
        out = {k: self.data[k] for k, cb in self.checkboxes.items()
               if cb.isChecked() and k in self.data}
        return out or None


# ── Main dialog ────────────────────────────────────────────────────────────────

class MetadataFetchDialog(QDialog):

    def __init__(self, parent, db, ids):
        QDialog.__init__(self, parent)
        self.db      = db
        self.ids     = ids
        self._panels = []
        self._errors  = []
        self.setWindowTitle('Metadata++ — Fetching from all sources')
        self.setMinimumSize(800, 620)
        self._build_ui()
        self._start()

    # ── UI ─────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)

        # Progress bar
        self.status_lbl = QLabel('Initialising…')
        self.progress   = QProgressBar()
        self.progress.setRange(0, 100)
        root.addWidget(self.status_lbl)
        root.addWidget(self.progress)

        # Tabs: Results | Log
        self.tabs = QTabWidget()
        root.addWidget(self.tabs)

        # Results tab
        results_widget = QWidget()
        rw_layout = QVBoxLayout(results_widget)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.container = QWidget()
        self.results_layout = QVBoxLayout(self.container)
        self.results_layout.addStretch()
        self.scroll.setWidget(self.container)
        rw_layout.addWidget(self.scroll)
        self.tabs.addTab(results_widget, 'Results')

        # Log tab — dark background for readability
        self.log_view = QTextBrowser()
        self.log_view.setStyleSheet(
            'background-color: #1e1e1e; color: #cccccc;'
            'font-family: monospace; font-size: 11px;'
        )
        self.log_view.setOpenExternalLinks(False)

        # Toolbar row inside Log tab
        log_widget  = QWidget()
        log_layout  = QVBoxLayout(log_widget)
        log_toolbar = QHBoxLayout()
        self._log_clear_btn = QPushButton('Clear log')
        self._log_clear_btn.setFixedWidth(90)
        self._log_clear_btn.clicked.connect(self.log_view.clear)
        log_toolbar.addWidget(self._log_clear_btn)
        log_toolbar.addStretch()
        log_layout.addLayout(log_toolbar)
        log_layout.addWidget(self.log_view)
        self.tabs.addTab(log_widget, 'Log')

        # Buttons
        btn_row = QHBoxLayout()
        self.sel_all_btn  = QPushButton('Select All')
        self.desel_btn    = QPushButton('Deselect All')
        self.apply_btn    = QPushButton('✔  Apply Selected Metadata')
        self.apply_btn.setEnabled(False)
        self.cancel_btn   = QPushButton('Cancel')
        self.close_btn    = QPushButton('Close')
        self.close_btn.setVisible(False)

        btn_row.addWidget(self.sel_all_btn)
        btn_row.addWidget(self.desel_btn)
        btn_row.addStretch()
        btn_row.addWidget(self.apply_btn)
        btn_row.addWidget(self.cancel_btn)
        btn_row.addWidget(self.close_btn)
        root.addLayout(btn_row)

        self.sel_all_btn.clicked.connect(self._select_all)
        self.desel_btn.clicked.connect(self._deselect_all)
        self.apply_btn.clicked.connect(self._apply)
        self.cancel_btn.clicked.connect(self._cancel)
        self.close_btn.clicked.connect(self.accept)

    # ── Worker wiring ──────────────────────────────────────────────────────────

    def _start(self):
        self.worker = FetchWorker(self.db, self.ids, self)
        self.worker.progress.connect(self._on_progress)
        self.worker.book_done.connect(self._on_book_done)
        self.worker.finished.connect(self._on_finished)
        self.worker.error_sig.connect(self._on_error)
        # Wire the log signaller that lives inside the worker
        self.worker._log_signaller.log_line.connect(self._append_log)
        self.worker.start()

    def _append_log(self, html_line):
        """Append one HTML line to the Log tab and auto-scroll to bottom."""
        self.log_view.append(html_line)
        sb = self.log_view.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _on_progress(self, pct, msg):
        self.progress.setValue(pct)
        self.status_lbl.setText(msg)

    def _on_book_done(self, book_id, mi, data):
        # Remove trailing stretch
        count = self.results_layout.count()
        last  = self.results_layout.itemAt(count - 1)
        if last and last.spacerItem():
            self.results_layout.removeItem(last)

        panel = BookResultPanel(book_id, mi, data)
        self.results_layout.addWidget(panel)
        self._panels.append(panel)
        self.results_layout.addStretch()

    def _on_error(self, msg):
        self._errors.append(msg)
        # Error is also forwarded via GUILogHandler, but keep the tab badge
        # updated by bumping the Log tab title
        idx = self.tabs.indexOf(self.tabs.findChild(QWidget, '') or self.tabs.widget(1))
        self.tabs.setTabText(1, 'Log ({} error{})'.format(
            len(self._errors), 's' if len(self._errors) != 1 else ''))

    def _on_finished(self):
        self.apply_btn.setEnabled(True)
        self.cancel_btn.setVisible(False)
        self.close_btn.setVisible(True)
        found = sum(1 for p in self._panels if p.data)
        self.status_lbl.setText(
            'Complete — {}/{} books with metadata. {} error(s).'.format(
                found, len(self._panels), len(self._errors))
        )
        # Always show Log tab badge with final counts
        ok  = found
        nok = len(self._panels) - found
        err = len(self._errors)
        badge = 'Log — ✔{} ✘{}{}'.format(
            ok, nok,
            ' ⚠{}'.format(err) if err else ''
        )
        self.tabs.setTabText(1, badge)

        # Switch to Log tab when there are errors OR when no results found
        if self._errors or found == 0:
            self.tabs.setCurrentIndex(1)

    # ── Bulk select ────────────────────────────────────────────────────────────

    def _select_all(self):
        for p in self._panels:
            for cb in p.checkboxes.values():
                cb.setChecked(True)

    def _deselect_all(self):
        for p in self._panels:
            for cb in p.checkboxes.values():
                cb.setChecked(False)

    # ── Apply ──────────────────────────────────────────────────────────────────

    # ── Cover helpers ──────────────────────────────────────────────────────────

    def _current_cover_quality(self, book_id):
        """
        Return the (pixels, file_bytes) quality tuple for the book's existing
        cover, or (0, 0) if it has none.
        Uses calibre's db API to read raw cover bytes directly — no network call.
        """
        try:
            from calibre_plugins.metadata_plus.providers import cover_quality, measure_image_bytes  # type: ignore
            raw = self.db.cover(book_id, index_is_id=True, as_file=False)
            if raw and len(raw) > 500:
                return cover_quality(raw)
        except Exception:
            pass
        return (0, 0)

    def _fetch_best_cover(self, panel):
        """
        Download the best candidate cover for a book result panel.

        Strategy
        --------
        1.  Try the main cover_url first (already chosen by probe_best_cover /
            best_cover in the fetch engine — highest-quality heuristic winner).
        2.  If that fails or yields a tiny image, try each cover_alt in order.
        3.  For every candidate URL, run is_audiobook_cover() before downloading
            — audiobook covers are skipped entirely without a network call.
        4.  Return (url, raw_bytes) for the first non-audiobook candidate that
            downloads to > 5 000 bytes, or (None, b'') if all fail.

        This is intentionally separate from the fetch-engine's probe_best_cover
        so that the actual download happens only at apply-time, not during the
        parallel metadata fetch (which already HEAD-probed to pick the URL).
        """
        from calibre_plugins.metadata_plus.providers import (  # type: ignore
            fetch_cover_bytes, is_audiobook_cover, cover_quality)

        if not panel.data:
            return None, b''

        candidates = []
        main = panel.data.get('cover_url', '')
        if main:
            candidates.append(main)
        for alt in panel.data.get('cover_alts', []) or []:
            if alt and alt not in candidates:
                candidates.append(alt)

        best_url, best_data, best_q = None, b'', (0, 0)

        for url in candidates:
            if is_audiobook_cover(url):
                continue
            data = fetch_cover_bytes(url, timeout=15)
            if len(data) < 5000:
                continue
            q = cover_quality(data)
            if q > best_q:
                best_q, best_url, best_data = q, url, data
            # Stop once we have something reasonably large (> 200 KB / > 400 px²)
            if best_q[0] > 400 * 400 and best_q[1] > 50_000:
                break

        return best_url, best_data

    # ── Apply ──────────────────────────────────────────────────────────────────

    def _apply(self):
        from calibre_plugins.metadata_plus.config import prefs  # type: ignore
        from calibre_plugins.metadata_plus.providers import cover_quality  # type: ignore

        applied = 0
        cover_kept = 0
        cover_updated = 0
        cover_skipped = 0   # auto_cover disabled or no URL

        for panel in self._panels:
            sel = panel.get_selected()
            if not sel:
                continue
            mi = self.db.get_metadata(panel.book_id, index_is_id=True)

            if sel.get('title'):      mi.title     = sel['title']
            if sel.get('authors'):    mi.authors   = list(sel['authors'])
            if sel.get('publisher'):  mi.publisher = sel['publisher']
            if sel.get('comments'):   mi.comments  = sel['comments']
            if sel.get('tags'):       mi.tags      = list(sel['tags'])
            if sel.get('language'):   mi.language  = sel['language']
            if sel.get('rating'):
                try:
                    mi.rating = float(sel['rating']) * 2
                except Exception:
                    pass
            if sel.get('identifiers'):
                mi.set_identifiers(sel['identifiers'])
            if sel.get('pubdate'):
                from calibre.utils.date import parse_date  # type: ignore
                try:
                    mi.pubdate = parse_date(sel['pubdate'])
                except Exception:
                    pass

            self.db.set_metadata(panel.book_id, mi, commit=True)
            applied += 1

            # ── Cover logic ────────────────────────────────────────────────
            # Rule 1: auto_cover must be enabled.
            # Rule 2: Download the best non-audiobook candidate cover.
            # Rule 3: Measure its dimensions vs the book's existing cover.
            #         Keep whichever is larger (more pixels × file bytes).
            #         If they are equal, prefer the fetched cover (it was
            #         chosen by the engine's quality-maximising probe).
            # This means a user's hand-picked high-res cover is NEVER
            # silently replaced by a lower-quality one from the internet.

            if not prefs.get('auto_cover', True) or not panel.data:
                cover_skipped += 1
                continue

            fetched_url, fetched_data = self._fetch_best_cover(panel)

            if not fetched_data:
                cover_skipped += 1
                continue

            existing_q = self._current_cover_quality(panel.book_id)
            fetched_q  = cover_quality(fetched_data)

            if fetched_q > existing_q:
                # Fetched cover is strictly better (more pixels, or same
                # pixels but larger file = more detail / less compression).
                self.db.set_cover(panel.book_id, fetched_data)
                cover_updated += 1
            else:
                # Existing cover is at least as good — keep it untouched.
                cover_kept += 1

        # Build a human-friendly summary line for the cover outcome
        cover_parts = []
        if cover_updated:
            cover_parts.append('{} cover(s) updated'.format(cover_updated))
        if cover_kept:
            cover_parts.append('{} existing cover(s) kept (already better)'.format(cover_kept))
        if cover_skipped:
            cover_parts.append('{} cover(s) skipped (no candidate / disabled)'.format(cover_skipped))
        cover_msg = '  |  '.join(cover_parts) if cover_parts else ''

        info_dialog(
            self, 'Metadata++ — Done',
            'Updated {} book(s){}.'.format(
                applied,
                '\n' + cover_msg if cover_msg else ''
            ),
            show=True,
        )
        self.accept()

    def _cancel(self):
        if hasattr(self, 'worker') and self.worker.isRunning():
            # Signal the worker to stop processing new books
            self.worker.abort()
            # Disconnect all signals from the worker before we destroy the
            # dialog.  If we call reject() while the worker thread is still
            # running and emitting signals (progress, book_done, log lines…),
            # Qt delivers those signals to the already-deleted C++ objects
            # that back the dialog's widgets, which causes a segfault /
            # Calibre crash.  Disconnecting here makes the remaining emits
            # safe no-ops from Qt's perspective.
            try:
                self.worker.progress.disconnect()
                self.worker.book_done.disconnect()
                self.worker.finished.disconnect()
                self.worker.error_sig.disconnect()
                self.worker._log_signaller.log_line.disconnect()
            except Exception:
                pass  # already disconnected or never connected — harmless
            # Wait briefly for the worker to finish its current network call
            # so we don't pull the rug out mid-write.  25 s is enough for
            # one provider timeout; we don't block the UI because abort()
            # makes the worker skip all remaining books immediately.
            self.worker.wait(25000)
        self.reject()


# ── Duplicate report dialog ────────────────────────────────────────────────────

class DuplicateDialog(QDialog):
    def __init__(self, parent, db, dupes):
        QDialog.__init__(self, parent)
        self.setWindowTitle('Metadata++ — Duplicate Detection')
        self.setMinimumSize(600, 400)
        layout = QVBoxLayout(self)
        if not dupes:
            layout.addWidget(QLabel('No duplicates detected in the selected books.'))
        else:
            layout.addWidget(QLabel('<b>{} potential duplicate pair(s) found:</b>'.format(len(dupes))))
            browser = QTextBrowser()
            lines = []
            for id1, id2 in dupes:
                mi1 = db.get_metadata(id1, index_is_id=True)
                mi2 = db.get_metadata(id2, index_is_id=True)
                lines.append(
                    '• <b>{}</b> / <i>{}</i><br>'
                    '  &nbsp;&nbsp;vs<br>'
                    '  <b>{}</b> / <i>{}</i><hr>'.format(
                        mi1.title, ', '.join(mi1.authors),
                        mi2.title, ', '.join(mi2.authors),
                    )
                )
            browser.setHtml('<br>'.join(lines))
            layout.addWidget(browser)
        btn = QPushButton('Close')
        btn.clicked.connect(self.accept)
        layout.addWidget(btn)
