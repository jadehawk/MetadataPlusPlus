#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai
__license__ = 'GPL v3'
"""
browser_fetch.py -- Playwright/Firefox browser layer -- MetadataPlusPlus v6.2.13

Provides browser_get(), a drop-in complement to providers._get() that drives
a real Firefox browser instead of urllib, bypassing bot-detection systems that
fingerprint server-side HTTP requests (missing browser headers, wrong TLS
fingerprint, no JS execution, etc.).

REQUIRES (one-time system-wide setup -- install into the SYSTEM Python):
    pip install playwright
    playwright install firefox

Architecture
------------
Playwright runs in a SYSTEM PYTHON SUBPROCESS, not inside Calibre's bundled
Python.  This is the only reliable approach because:

  - Calibre embeds its own Python interpreter.
  - Installing playwright into Calibre's Python causes dependency conflicts.
  - Even with sys.path injection, compiled C extensions (greenlet, the
    playwright browser binaries) built for one Python version cannot load
    inside a different Python's interpreter (ABI mismatch).

Each browser_get() call:
  1. Finds the system Python that has playwright (cached after first probe).
  2. Writes a small self-contained fetch script to a temp file.
  3. Runs it via the system Python, capturing rendered HTML from stdout.
  4. Deletes the temp file.

The per-call startup cost is ~3-5 s (Firefox launch + page load).  This is
acceptable because the browser is only a fallback for bot-blocked sources --
it is never called when the regular urllib path succeeds.

Integration pattern in providers.py
-------------------------------------
    raw = _get(url, timeout, retries, headers=hdrs, log=log)
    if (not raw or <blocked_check>(raw)) and _browser_fallback_enabled():
        log.info('Source: urllib blocked -- retrying via browser')
        raw = _browser_get(url, headers=hdrs, timeout=timeout, log=log)
"""

import sys
import os
import subprocess
import tempfile
import threading

# Suppress console windows created by subprocess calls on Windows.
# Without this every Popen/run call spawns a visible black CMD window.
_CREATE_NO_WINDOW = 0x08000000 if sys.platform == 'win32' else 0


# ── System Python discovery ────────────────────────────────────────────────────
_find_lock             = threading.Lock()
_system_python_cmd     = None   # e.g. ['py', '-3.11'] or ['python']
_system_python_checked = False  # True after first probe (even if none found)

# ── Browser serialisation ──────────────────────────────────────────────────────
# Only one Firefox subprocess at a time.  Browser calls are already rare
# (fallback-only) so the queue cost is negligible.
_browser_semaphore = threading.Semaphore(1)


def _find_system_python_with_playwright():
    """
    Find and cache the system Python command that has playwright installed.

    Probes Python Launcher versioned variants first (py -3.12, py -3.11, ...)
    then falls back to simple executable names.  Skips Calibre's own Python.

    Returns a list like ['py', '-3.11'] or ['python'], or None if not found.
    Thread-safe -- the expensive probe runs at most once per Calibre session.
    """
    global _system_python_cmd, _system_python_checked

    if _system_python_checked:
        return _system_python_cmd

    with _find_lock:
        if _system_python_checked:
            return _system_python_cmd
        _system_python_checked = True

        calibre_exe  = os.path.normcase(os.path.realpath(sys.executable))
        check_script = 'from playwright.sync_api import sync_playwright; print("ok")'

        # Python Launcher versioned variants -- try older/more-stable versions
        # first since playwright is often installed for an LTS Python rather
        # than the newest available (3.14 is very recent and may lack packages).
        py_launcher_variants = [
            ['py', '-3.12'], ['py', '-3.11'], ['py', '-3.10'],
            ['py', '-3.13'], ['py', '-3.9'],  ['py', '-3'],
        ]
        simple_candidates = ['python3', 'python', 'py', 'python3.exe', 'python.exe']

        def _test(cmd_parts):
            """Return True if cmd_parts runs a non-Calibre Python that has playwright."""
            try:
                id_r = subprocess.run(
                    cmd_parts + ['-c', 'import sys; print(sys.executable)'],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5,
                    creationflags=_CREATE_NO_WINDOW,
                )
                if id_r.returncode == 0:
                    real = os.path.normcase(os.path.realpath(
                        id_r.stdout.decode('utf-8', errors='replace').strip()
                    ))
                    if real == calibre_exe:
                        return False  # this IS Calibre's Python -- skip it
                r = subprocess.run(
                    cmd_parts + ['-c', check_script],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10,
                    creationflags=_CREATE_NO_WINDOW,
                )
                return r.returncode == 0
            except (OSError, subprocess.TimeoutExpired, Exception):
                return False

        for parts in py_launcher_variants:
            if _test(parts):
                _system_python_cmd = parts
                return parts

        for exe in simple_candidates:
            if _test([exe]):
                _system_python_cmd = [exe]
                return [exe]

        return None


# ── Firefox UA ─────────────────────────────────────────────────────────────────
# Use the same UA a real Firefox 125 on Windows 10 x64 sends.
# A Chrome UA paired with a Firefox TLS fingerprint is a high-confidence bot
# signal on Cloudflare/Akamai/PerimeterX -- never mix them.
_FIREFOX_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) '
    'Gecko/20100101 Firefox/125.0'
)

# ── Stealth JS (single-line so repr() embeds cleanly in the subprocess script) ─
_STEALTH_JS = (
    "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
    "if(navigator.plugins.length===0){"
    "Object.defineProperty(navigator,'plugins',{get:()=>{"
    "const a=[1,2,3];a.item=i=>a[i];a.namedItem=()=>null;a.refresh=()=>{};return a;"
    "}});"
    "}"
    "try{Object.defineProperty(navigator,'languages',{"
    "get:()=>(navigator.language?[navigator.language,'en']:['en-US','en'])"
    "});}catch(e){}"
    "try{delete window.__playwright;}catch(e){}"
    "try{delete window.__pw_manual;}catch(e){}"
    "try{delete window.__PW_inspect;}catch(e){}"
)

# ── Firefox user prefs (same for every call) ───────────────────────────────────
_FF_PREFS = {
    # Disable WebRTC -- local IP leaks are a common bot-detection signal.
    'media.peerconnection.enabled':              False,
    # Leave resistFingerprinting OFF -- its spoofed canvas/screen values are
    # themselves a detection signal on sophisticated WAFs.
    'privacy.resistFingerprinting':              False,
    # Suppress background update/telemetry requests.
    'app.update.auto':                           False,
    'app.update.enabled':                        False,
    'toolkit.telemetry.enabled':                 False,
    'datareporting.healthreport.uploadEnabled':  False,
}


# ── Public API ─────────────────────────────────────────────────────────────────

def is_browser_available():
    """
    Return True if a system Python with playwright is reachable.

    The underlying probe runs at most once per Calibre session (cached).
    Subsequent calls are a fast dict/bool lookup.
    """
    return _find_system_python_with_playwright() is not None


def browser_get(url, headers=None, timeout=30, log=None):
    """
    Fetch `url` using Playwright Firefox in a system Python subprocess.
    Returns the fully-rendered page HTML as a str, or None on failure.

    Parameters
    ----------
    url     : str  -- page to fetch
    headers : dict -- optional extra HTTP request headers (Accept-Language
                      is used to set the browser locale)
    timeout : int  -- page-load timeout in seconds (default 30)
    log           -- calibre/standard logger, or None
    """
    sys_python = _find_system_python_with_playwright()
    if sys_python is None:
        if log:
            log.warning(
                'browser_fetch: no system Python with playwright found. '
                'Install commands:\n'
                '  1.  pip install playwright\n'
                '  2.  playwright install firefox'
            )
        return None

    # Read headless and timeout from plugin prefs (fall back to defaults).
    # DEBUG: default is False so Firefox window is visible for diagnosis.
    headless = False
    try:
        from calibre_plugins.metadata_plus.config import prefs  # type: ignore
        headless = bool(prefs.get('browser_headless', True))
        timeout  = int(prefs.get('browser_timeout', timeout))
    except Exception:
        pass

    hdrs        = headers or {}
    accept_lang = hdrs.get('Accept-Language', 'en-US,en;q=0.9')
    locale      = accept_lang.split(',')[0].strip()
    timeout_ms  = int(timeout * 1000)

    extra_headers = {
        'Accept': (
            'text/html,application/xhtml+xml,application/xml;'
            'q=0.9,image/avif,image/webp,*/*;q=0.8'
        ),
        'Accept-Language':           accept_lang,
        'Accept-Encoding':           'gzip, deflate, br',
        'Cache-Control':             'no-cache',
        'Pragma':                    'no-cache',
        'Upgrade-Insecure-Requests': '1',
        'DNT':                       '1',
        'Sec-Fetch-Dest':            'document',
        'Sec-Fetch-Mode':            'navigate',
        'Sec-Fetch-Site':            'none',
        'Sec-Fetch-User':            '?1',
    }

    # Build the subprocess script with all parameters embedded as safe
    # Python literals via repr().  Writing to a temp file avoids any quoting
    # issues with -c arguments on Windows.
    script_lines = [
        'import sys, time, random',
        'from playwright.sync_api import sync_playwright',
        '',
        f'_url        = {repr(url)}',
        f'_headless   = {repr(headless)}',
        f'_timeout_ms = {repr(timeout_ms)}',
        f'_locale     = {repr(locale)}',
        f'_ua         = {repr(_FIREFOX_UA)}',
        f'_extra_hdrs = {repr(extra_headers)}',
        f'_stealth_js = {repr(_STEALTH_JS)}',
        f'_ff_prefs   = {repr(_FF_PREFS)}',
        '',
        # ── Resource blocker (matches reference playwright_utils.py) ──────────
        # Blocks heavy resources that don't contribute to metadata content:
        # stylesheets, fonts, media, and known ad/analytics domains.
        # Cover images from Amazon CDN and Goodreads are explicitly allowed.
        # This dramatically reduces the number of pending network requests so
        # wait_until="networkidle" completes much faster (especially on
        # Goodreads, which loads dozens of trackers and social widgets).
        'def _block_resources(route, request):',
        '    u = request.url.lower()',
        '    # Always allow main cover image CDNs',
        '    if "m.media-amazon.com" in u or "images-na.ssl-images-amazon.com" in u:',
        '        return route.continue_()',
        '    if "goodreads.com" in u and ("/books/" in u or "/images/" in u):',
        '        return route.continue_()',
        '    # Block heavy resource types that are irrelevant to HTML content',
        '    if request.resource_type in ("stylesheet", "font", "media"):',
        '        return route.abort()',
        '    # Block known heavy ad/analytics/tracking domains',
        '    _blocked = ("google-analytics.com","doubleclick.net","amazon-adsystem.com",',
        '                "fls-na.amazon.com","amazonvideo.com","googletagmanager.com",',
        '                "facebook.com","twitter.com","scorecardresearch.com",',
        '                "quantserve.com","omtrdc.net","amazon-adsystem.com")',
        '    if any(d in u for d in _blocked):',
        '        return route.abort()',
        '    return route.continue_()',
        '',
        # ── Amazon "Click to continue" challenge handler ───────────────────────
        'def _handle_continue_challenge(page):',
        '    selectors = ["input#continue",',
        '                 "xpath=/html/body/div/div[1]/div[3]/div/div/form/div/div/span"]',
        '    for sel in selectors:',
        '        try:',
        '            btn = page.locator(sel)',
        '            if btn.count() > 0 and btn.first.is_visible(timeout=1000):',
        '                btn.first.click(timeout=3000)',
        '                page.wait_for_load_state("domcontentloaded", timeout=5000)',
        '                page.wait_for_timeout(1500)',
        '                return True',
        '        except Exception:',
        '            continue',
        '    return False',
        '',
        'try:',
        '    with sync_playwright() as pw:',
        '        browser = pw.firefox.launch(',
        '            headless=_headless,',
        '            args=["--no-sandbox"],',
        '            firefox_user_prefs=_ff_prefs,',
        '        )',
        '        ctx = browser.new_context(',
        '            viewport={"width": 1366, "height": 768},',
        '            user_agent=_ua,',
        '            locale=_locale,',
        '            timezone_id="America/New_York",',
        '            extra_http_headers=_extra_hdrs,',
        '        )',
        '        page = ctx.new_page()',
        '        page.add_init_script(_stealth_js)',
        # Block heavy resources before navigating so they never hit the network.
        # This is the single biggest speed-up for slow sites like Goodreads.
        '        page.route("**/*", _block_resources)',
        '        time.sleep(0.3 + random.random() * 0.5)',
        # wait_until="networkidle" waits for all network activity to finish,
        # which lets Cloudflare/bot-challenge JS redirects complete before we
        # capture content.  "domcontentloaded" fires on the challenge page
        # itself (typically ~1-2 KB) before the redirect to the real page.
        # With resource blocking active, networkidle completes much faster
        # since most pending requests are aborted before they even start.
        '        page.goto(_url, wait_until="networkidle", timeout=_timeout_ms)',
        # Handle Amazon's "Click to continue" challenge if it appears.
        '        _handle_continue_challenge(page)',
        # Extra breathing room after networkidle -- some SPAs fire late XHRs.
        '        page.wait_for_timeout(1500 + random.randint(0, 500))',
        '        html = page.content()',
        # Safety net: if content is suspiciously small the challenge may still
        # be resolving (e.g. a slow Cloudflare turnstile).  Wait and re-sample.
        '        if len(html.encode("utf-8")) < 5000:',
        '            page.wait_for_timeout(4000 + random.randint(0, 1000))',
        '            html = page.content()',
        '        final_url = page.url',
        '        ctx.close()',
        '        browser.close()',
        '    sys.stdout.buffer.write(html.encode("utf-8", errors="replace"))',
        '    sys.stderr.write("browser_fetch:final_url=" + final_url + "\\n")',
        'except Exception as _e:',
        '    sys.stderr.write(str(_e) + "\\n")',
        '    sys.exit(1)',
    ]
    script_content = '\n'.join(script_lines)

    tmp_path = None
    try:
        # Write script to a temp file.
        with tempfile.NamedTemporaryFile(
            mode='w', suffix='_mpp_browser.py',
            delete=False, encoding='utf-8'
        ) as f:
            f.write(script_content)
            tmp_path = f.name

        if log:
            log.info(
                'browser_fetch: launching Firefox (%s headless=%s) for %s',
                ' '.join(sys_python), headless, url[:80]
            )

        # Serialise: only one Firefox process at a time.
        with _browser_semaphore:
            result = subprocess.run(
                sys_python + [tmp_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout + 20,
                creationflags=_CREATE_NO_WINDOW,
            )

        if result.returncode == 0 and result.stdout:
            html = result.stdout.decode('utf-8', errors='replace')
            if log:
                # The subprocess writes "browser_fetch:final_url=<url>" to
                # stderr on success so we can show where we actually landed
                # (useful to confirm that challenge redirects completed).
                stderr_txt = result.stderr.decode('utf-8', errors='replace')
                final_url  = url
                for line in stderr_txt.splitlines():
                    if line.startswith('browser_fetch:final_url='):
                        final_url = line.split('=', 1)[1].strip()
                        break
                log.debug(
                    'browser_fetch: fetched %d bytes; final_url=%s',
                    len(html), final_url[:100]
                )
            return html if html.strip() else None

        if log:
            err = result.stderr.decode('utf-8', errors='replace').strip()
            # Filter out the final_url marker line from error display.
            err_lines = [l for l in err.splitlines()
                         if not l.startswith('browser_fetch:final_url=')]
            err_clean = '\n'.join(err_lines).strip()
            log.warning(
                'browser_fetch: subprocess failed for %s: %s',
                url[:80], err_clean[-300:] if err_clean else '(no stderr)'
            )
        return None

    except subprocess.TimeoutExpired:
        if log:
            log.warning('browser_fetch: timed out for %s', url[:80])
        return None
    except Exception as e:
        if log:
            log.warning('browser_fetch: error for %s: %s', url[:80], e)
        return None
    finally:
        # Always clean up the temp script.
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass


def browser_close():
    """
    No-op in the subprocess architecture -- there is no persistent browser
    process to shut down.  Kept for API compatibility with any callers.
    """
    pass
